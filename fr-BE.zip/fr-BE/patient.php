<?php

return [
    'patient_deleted' => "Le dossier du patient a bien été supprimé .",
    'no_data_for_patient' => "No data for patient"
];
