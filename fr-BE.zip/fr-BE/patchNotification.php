<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'notifications_count' => 'Notification Count.',
    'notifications_hidden' => 'Notification masquée.',
    'updated' => ':className Mise à jour.',
    'deleted' => ':className Supprimé.',
    'detail' => ':className.',
    'byCriteria' => ':className By :field List.',
    'ok'=>'OK'
];
