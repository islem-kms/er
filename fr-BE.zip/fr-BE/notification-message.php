<?php

return [
    'notification_message' => "{1} <b> :qtt-patient-name </b> a reçu un traitement Qutenza il y a plus de :qtt-number heures . Veuillez contacter le patient pour passer en revue l'efficacité du traitement et voir comment il a toléré le traitement.
                                |[2,*] <b> :qtt-patient-name </b> a reçu un traitement Qutenza il y a plus de :qtt-number jours . Veuillez contacter le patient pour passer en revue l'efficacité du traitement et voir comment il a toléré le traitement.",
];
