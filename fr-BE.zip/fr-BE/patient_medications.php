<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'list' => ':className List.',
    'created' => ':className Créé.',
    'updated' => ':className Mise à jour.',
    'deleted' => ':className Supprimé.',
    'detail' => ':className.',
    'byCriteria' => 'Liste de :className selon :field ',
    'unauthorized' => 'Action non autorisée: Le patient doit avoir au moins une PNP.',


];
