<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'list' => ':className List.',
    'created' => 'Le rendez-vous a bien été créé.',
    'updated' => 'Les détails du rendez-vous ont été mis à jour.',
    'deleted' => 'Le rendez-vous a bien été supprimé.',
    'detail' => ':className.',
    'byCriteria' => 'Liste de :className selon :field .',
    'unauthorized' => 'Action non autorisée..',
    'booked' => 'Action non autorisée : plage horaire déjà réservée.',
    'user_consultations' => "nombre de consultations de l'utilisateurs",
    'unauthorized_delete' => 'Action non autorisée.',

];
