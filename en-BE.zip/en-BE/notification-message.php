<?php

return [
    'notification_message' => '{1} <b>:qtt-patient-name </b>has received a Qutenza® treatment more than :qtt-number hours ago. Please contact the patient to review treatment efficacy and see how the patient tolerated the treatment.
    |[2,*] <b> :qtt-patient-name </b> has received a Qutenza® treatment more than :qtt-number days ago. Please contact the patient to review the effectiveness of the treatment and see how the patient tolerated the treatment.'
];
