<?php

return [
    'patient_deleted' => "The patient's file was deleted successfully.",
    'no_data_for_patient' => "No data for patient"
];
