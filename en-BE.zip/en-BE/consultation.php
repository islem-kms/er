<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'list' => ':className List.',
    'created' => 'The appointment was successfully created.',
    'updated' => 'The appointment details have been updated.',
    'deleted' => 'The appointment was successfully Deleted.',
    'detail' => ':className.',
    'byCriteria' => ':className By :field List.',
    'unauthorized' => 'Unauthorized action.',
    'booked' => 'Unauthorized action: Time slot already booked.',
    'user_consultations' => 'number of user consultations',
    'unauthorized_delete' => 'Unauthorized delete action.',
];
