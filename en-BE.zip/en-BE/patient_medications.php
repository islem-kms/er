<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'list' => ':className List.',
    'created' => ':className Created.',
    'updated' => ':className Updated.',
    'deleted' => ':className Deleted.',
    'detail' => ':className.',
    'byCriteria' => ':className By :field List.',
    'unauthorized' => 'Unauthorized action: Patient should have at least one PNP.',


];
